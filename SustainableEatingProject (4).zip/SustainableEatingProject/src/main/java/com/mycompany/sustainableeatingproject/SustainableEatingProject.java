/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.sustainableeatingproject;

/**
 *
 * @author jamie
 */
public class SustainableEatingProject {

    public static void main(String[] args) {
        
    }
}
